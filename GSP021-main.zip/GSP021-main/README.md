# GSP021

Orchestrating the Cloud with Kubernetes

https://www.qwiklabs.com/focuses/557?parent=catalog


# using Cloudshell
> git clone https://github.com/gablooge/GSP021.git

> cd GSP021

> sudo chmod +x cloudshell.sh

> ./cloudshell.sh


# using gcloud SDK Client
## Terminal 1
> git clone https://github.com/gablooge/GSP021.git

> cd GSP021

> sudo chmod +x 1.sh

> ./1.sh


## Terminal 2 for gcloud authentication
> gcloud init



